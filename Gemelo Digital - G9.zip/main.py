# Proyecto ISCF - Gemelo digital en Wokwi 

from machine import Pin
from time import sleep
import dht
import onewire, ds18x20

# pines
PIN_DHT    = 15          # DHT22 
PIN_1WIRE  = 13          # DS18B20 (DQ) 
PIN_LED_R  = 12          # LED rojo
PIN_LED_G  = 14          # LED verde
PIN_LED_B  = 27          # LED azul
PIN_BUZZ   = 5           # buzzer 


COMMON_ANODE = True  

#  umbrales del proceso 
TEMP_OK_MIN = 50.0     # °C
TEMP_OK_MAX = 70.0     # °C
HUM_AMB_MIN = 30.0     # %HR
HUM_AMB_MAX = 90.0     # %HR

# simulación de respaldo 
# como el sensor digital esta en beta no tira valores, por lo tanto uso valores de respaldo
FORCE_SIM_IF_ZERO = True
SIM_VALUES = [55.0, 57.5, 53.0]   

print("BOOT | DHT@{}, 1-Wire@{}, LED R/G/B {} {} {}, BUZZ {}".format(
    PIN_DHT, PIN_1WIRE, PIN_LED_R, PIN_LED_G, PIN_LED_B, PIN_BUZZ))

# sensores 
dht_sensor = dht.DHT22(Pin(PIN_DHT))
ow = onewire.OneWire(Pin(PIN_1WIRE))
ds = ds18x20.DS18X20(ow)
roms = ds.scan()
print("ROMs iniciales:", roms if roms else "ninguna (se reintenta)")

#  actuadores 
led_r = Pin(PIN_LED_R, Pin.OUT); led_r.off()
led_g = Pin(PIN_LED_G, Pin.OUT); led_g.off()
led_b = Pin(PIN_LED_B, Pin.OUT); led_b.off()
buzzer = Pin(PIN_BUZZ, Pin.OUT); buzzer.off()

def led_color(r: bool, g: bool, b: bool):
    if COMMON_ANODE:
        led_r.value(0 if r else 1)
        led_g.value(0 if g else 1)
        led_b.value(0 if b else 1)
    else:
        led_r.value(1 if r else 0)
        led_g.value(1 if g else 0)
        led_b.value(1 if b else 0)

def beep(times=1, t_on=0.1, t_off=0.1):
    for _ in range(times):
        buzzer.on(); sleep(t_on)
        buzzer.off(); sleep(t_off)

def estado_ok():
    led_color(False, True, False)   # verde

def estado_advertencia():
    led_color(True, True, False)    # amarillo
    beep(times=2, t_on=0.08, t_off=0.12)

def estado_critico():
    led_color(True, False, False)   # rojo
    beep(times=5, t_on=0.1, t_off=0.1)

# loop para que arroje lecturas cada 15ms 
SCAN_EVERY = 15
loops = 0

while True:
    # de DHT22 
    try:
        dht_sensor.measure()
        t_amb = float(dht_sensor.temperature())
        h_amb = float(dht_sensor.humidity())
    except Exception as e:
        print("Error DHT22:", e)
        t_amb, h_amb = float("nan"), float("nan")

    # de DS18B20 
    if (not roms) or (loops % SCAN_EVERY == 0):
        roms = ds.scan()

    t_internas = []
    have_real = False
    if roms:
        try:
            ds.convert_temp()
            sleep(0.75)
            for r in roms:
                val = ds.read_temp(r)
                if val is not None:
                    v = float(val)
                    t_internas.append(v)
            # ¿hay alguna lectura distinta de 0.0?
            have_real = any(abs(v) > 0.01 for v in t_internas)
        except Exception as e:
            print("Error DS18B20:", e)

    if FORCE_SIM_IF_ZERO and (not roms or not have_real):
        t_internas = SIM_VALUES[:]

    #  salidas 
    t_prom = sum(t_internas)/len(t_internas) if t_internas else float("nan")
    t_max  = max(t_internas) if t_internas else float("nan")

    print("---- Lecturas ----")
    print("T internas:", ["{:.1f}".format(x) for x in t_internas] if t_internas else "N/D")
    print("T int prom: {:.1f} °C | T int máx: {:.1f} °C".format(t_prom, t_max) if t_internas else "Sin DS18B20")
    print("T amb: {:.1f} °C | HR amb: {:.1f} %".format(t_amb, h_amb))

    critico = (t_internas and t_max > TEMP_OK_MAX)
    advert_temp_baja = (t_internas and t_prom < TEMP_OK_MIN)
    advert_hum_amb   = (h_amb == h_amb) and not (HUM_AMB_MIN <= h_amb <= HUM_AMB_MAX)

    if critico:
        estado_critico()
        estado_txt = "CRITICO (T interna > {:.0f} °C)".format(TEMP_OK_MAX)
    elif advert_temp_baja or advert_hum_amb:
        estado_advertencia()
        if advert_temp_baja and advert_hum_amb:
            estado_txt = "ADVERTENCIA (T baja y HR amb fuera de rango)"
        elif advert_temp_baja:
            estado_txt = "ADVERTENCIA (T interna < {:.0f} °C)".format(TEMP_OK_MIN)
        else:
            estado_txt = "ADVERTENCIA (HR amb fuera de rango)"
    else:
        estado_ok()
        estado_txt = "OK (termofilia en rango)"

    print("Estado:", estado_txt)
    print("-------------------")
    loops += 1
    sleep(2)
